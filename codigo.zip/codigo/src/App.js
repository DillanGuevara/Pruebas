import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Home from './pages/Home';
import Categorías from './pages/Categorías';
import Productos from './pages/Productos';
import Proveedor from './pages/Proveedores';
import Cliente from './pages/Clientes';
import Login from './components/Login';
import Registro from './components/Registro';
import Ventas from './pages/Ventas';
import Compras from './pages/Compras';
import NuevaCategoría from './pages/NuevaCategoría';
import EditarCategoría from './pages/EditarCategoría';
import NuevoProducto from './pages/NuevoProducto';
import EditarProducto from './pages/EditarProducto';
import NuevoProveedor from './pages/NuevoProveedor';
import EditarProveedor from './pages/EditarProveedor';
import NuevoCliente from './pages/NuevoCliente';
import EditarCliente from './pages/EditarCliente';
import NuevaVenta from './pages/NuevaVenta';
import EditarVenta from './pages/EditarVenta';
import NuevaCompra from './pages/NuevaCompra';
import EditarCompra from './pages/EditarCompra';

function App() {
  const [categorias, setCategorias] = useState([
    { id: 1, nombre: 'Categoría 1' },
    { id: 2, nombre: 'Categoría 2' },
  ]);

  const handleAddCategoria = (nuevaCategoria) => {
    setCategorias([...categorias, nuevaCategoria]);
  };

  const redirectToCategorias = () => {
    window.location.href = "/categorías"; // Redirigir a la página de categorías
  };

  const [productos, setProductos] = useState([
    { id: 1, nombre: 'Producto 1', categoría: 'Categoría 1', precio: 10, stock: 20, estado: 'Activo' },
    { id: 2, nombre: 'Producto 2', categoría: 'Categoría 2', precio: 20, stock: 30, estado: 'Inactivo' },
  ]);

  const handleAddProducto = (nuevoProducto) => {
    setProductos([...productos, nuevoProducto]);
  };

  const redirectToProductos = () => {
    window.location.href = "/productos"; // Redirigir a la página de productos
  };

  const [proveedores, setProveedor] = useState([
    { id: 1, nombre: 'Producto 1', categoría: 'Categoría 1', precio: 10, stock: 20, estado: 'Activo' },
    { id: 2, nombre: 'Producto 2', categoría: 'Categoría 2', precio: 20, stock: 30, estado: 'Inactivo' },
  ]);

  const handleAddProveedor = (nuevoProveedor) => {
    setProveedor([...proveedores, nuevoProveedor]);
  };

  const redirectToProveedor = () => {
    window.location.href = "/proveedores";
  };

  const [clientes, setCliente] = useState([
    { id: 1, nombre: 'Producto 1', categoría: 'Categoría 1', precio: 10, stock: 20, estado: 'Activo' },
    { id: 2, nombre: 'Producto 2', categoría: 'Categoría 2', precio: 20, stock: 30, estado: 'Inactivo' },
  ]);

  const handleAddCliente = (nuevoCliente) => {
    setCliente([...clientes, nuevoCliente]);
  };

  const redirectToCliente = () => {
    window.location.href = "/clientes";
  };

  const [ventas, setVentas] = useState([
    { id: 1, nombre: 'Producto 1', categoría: 'Categoría 1', precio: 10, stock: 20, estado: 'Activo' },
    { id: 2, nombre: 'Producto 2', categoría: 'Categoría 2', precio: 20, stock: 30, estado: 'Inactivo' },
  ]);

  const handleAddVentas = (nuevaVenta) => {
    setVentas([...compras, nuevaVenta]);
  };

  const redirectToVentas = () => {
    window.location.href = "/ventas";
  };

  const [compras, setCompras] = useState([
    { id: 1, nombre: 'Producto 1', fecha: 12/6/2023, proveedor: 'Proveedor 1', precio: 100000, total: 20, estado: 'Activo' },
    { id: 2, nombre: 'Producto 2', fecha: 6/2/2024, proveedor: 'Proveedor 2', precio: 120000, total: 30, estado: 'Inactivo' },
  ]);

  const handleAddCompras = (nuevaCompra) => {
    setCompras([...compras, nuevaCompra]);
  };

  const redirectToCompras = () => {
    window.location.href = "/compras";
  };

  return (
    <div className="app">
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/sidebar" element={<Sidebar />} />
        <Route path="/home" element={<Home />} />
        <Route path="/categorías" element={<Categorías categorias={categorias} setCategorias={setCategorias} />} />
        <Route path="/productos" element={<Productos productos={productos} setProductos={setProductos} />} />
        <Route path="/proveedores" element={<Proveedor proveedor={proveedores} setProveedor={setProveedor} />} />
        <Route path="/clientes" element={<Cliente cliente={clientes} setCliente={setCliente} />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/ventas" element={<Ventas venta={ventas} setVentas={setVentas} />} />
        <Route path="/compras" element={<Compras compra={compras} setCompras={setCompras} />} />
        <Route
          path="/nueva-categoria"
          element={<NuevaCategoría onAddCategoria={handleAddCategoria} redirectToCategorias={redirectToCategorias} setCategorias={setCategorias} />}
        />
        <Route path="/editar-categoria/:id" element={<EditarCategoría />} />
        <Route
          path="/nuevo-producto" // Cambio de ruta de nueva-categoria a nuevo-producto
          element={<NuevoProducto onAddProducto={handleAddProducto} redirectToProductos={redirectToProductos} setProductos={setProductos} />}
        />
        <Route path="/editar-producto/:id" element={<EditarProducto />} />
        <Route
          path="/nuevo-proveedor" // Cambio de ruta de nueva-categoria a nuevo-producto
          element={<NuevoProveedor onAddProveedor={handleAddProveedor} redirectToProveedor={redirectToProveedor} setProveedor={setProveedor} />}
        />
        <Route path="/editar-proveedor/:id" element={<EditarProveedor />} />
        <Route path="/editar-producto/:id" element={<EditarProducto />} />
        <Route
          path="/nuevo-cliente" // Cambio de ruta de nueva-categoria a nuevo-producto
          element={<NuevoCliente onAddCliente={handleAddCliente} redirectToCliente={redirectToCliente} setCliente={setCliente} />}
        />
        <Route path="/editar-cliente/:id" element={<EditarCliente />} />
        <Route
          path="/nueva-venta"
          element={<NuevaVenta onAddVenta={handleAddVentas} redirectToVentas={redirectToVentas} setVentas={setVentas} />}
        />
        <Route path="/editar-venta/:id" element={<EditarVenta />} />
        <Route
          path="/nueva-compra"
          element={<NuevaCompra onAddCompra={handleAddCompras} redirectToCompras={redirectToCompras} setCompras={setCompras} />}
        />
        <Route path="/editar-compra/:id" element={<EditarCompra />} />
      </Routes>
    </div>
  );
}

export default App;
