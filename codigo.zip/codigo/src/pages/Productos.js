import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

// Supongamos que tienes una lista de productos
let productos = [
  { id: 1, nombre: 'Careta de protección', categoría: 'Industrial', precio: 30000, stock: 50, estado: 'Activo' },
  { id: 2, nombre: 'Alcohol antiséptico', categoría: 'Bioseguridad', precio: 20000, stock: 50, estado: 'Activo' },
  { id: 3, nombre: 'Botas industriales', categoría: 'Industrial', precio: 40000, stock: 50, estado: 'Activo' },
  // Otros productos...
];

export const getProductById = async (id) => {
  try {
    // Simulamos una llamada a una API que devuelve el producto por su ID
    const producto = productos.find(producto => producto.id === parseInt(id));
    if (!producto) {
      throw new Error('Producto no encontrado');
    }
    return producto;
  } catch (error) {
    throw new Error(`Error al obtener el producto: ${error.message}`);
  }
};

export const updateProduct = async (productoActualizado) => {
  try {
    // Simulamos la actualización del producto en la lista de productos
    productos = productos.map(producto => {
      if (producto.id === productoActualizado.id) {
        return { ...producto, nombre: productoActualizado.nombre };
      }
      return producto;
    });
    // Simulamos una llamada a una API para actualizar el producto
    return true; // Devolvemos true para indicar que la actualización fue exitosa
  } catch (error) {
    throw new Error(`Error al actualizar el producto: ${error.message}`);
  }
};

const Productos = () => {
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    // Lógica para obtener la lista de productos
    // En este ejemplo, simularemos una llamada a una API para obtener los productos
    // getProductList().then(data => setProductos(data));
    // Aquí simplemente inicializamos con datos de ejemplo
    setProductos([
      { id: 1, nombre: 'Careta de protección', categoría: 'Industrial', precio: 30000, stock: 50, estado: 'Activo' },
      { id: 2, nombre: 'Alcohol antiséptico', categoría: 'Bioseguridad', precio: 20000, stock: 50, estado: 'Activo' },
      { id: 3, nombre: 'Botas industriales', categoría: 'Industrial', precio: 40000, stock: 50, estado: 'Activo' },
      // Otros productos...
    ]);
  }, []);

  // Función para actualizar un producto
  const handleUpdateProduct = async (productoActualizado) => {
    try {
      await updateProduct(productoActualizado);
      // Si la actualización es exitosa, actualizamos el estado del producto
      setProductos(productos.map(producto => {
        if (producto.id === productoActualizado.id) {
          return productoActualizado;
        }
        return producto;
      }));
      // Otra opción sería volver a obtener la lista de productos desde la API para reflejar los cambios
    } catch (error) {
      console.error('Error al actualizar el producto:', error);
    }
  };

  // Función para eliminar un producto
  const handleDeleteProduct = (id) => {
    setProductos(productos.filter(producto => producto.id !== id));
  };

  return (
    <div className="productos-container">
      <center><h1 style={{ fontFamily: 'Arial' }}>Productos</h1></center><br/>
      <button><Link to="/home" style={{ textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{ fontFamily: 'Arial' }}>Nombre</th>
            <th style={{ fontFamily: 'Arial' }}>Categoría</th>
            <th style={{ fontFamily: 'Arial' }}>Precio</th>
            <th style={{ fontFamily: 'Arial' }}>Stock</th>
            <th style={{ fontFamily: 'Arial' }}>Estado</th>
            <th style={{ fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {productos.map(producto => (
            <tr key={producto.id}>
              <td>{producto.nombre}</td>
              <td>{producto.categoría}</td>
              <td>{producto.precio}</td>
              <td>{producto.stock}</td>
              <td>{producto.estado}</td>
              <td>
                {/* Enlace a la página de edición del producto */}
                <button><Link to={{
                  pathname: `/editar-producto/${producto.id}`,
                  state: { producto } // Pasamos el objeto del producto como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar el producto */}
                <button onClick={() => handleDeleteProduct(producto.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevoProducto */}
      <center><h1><Link to="/nuevo-producto" className="link" style={{ color: 'black', textDecoration: 'none' }}>Agregar Producto</Link></h1></center>
    </div>
  );
};

export default Productos;
