import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import jsPDF from 'jspdf';

// Supongamos que tienes una lista de ventas
let ventas = [
  { id: 1, producto: 'Producto A', cantidad: 5, total: 100000 },
  { id: 2, producto: 'Producto B', cantidad: 3, total: 75000 },
  { id: 3, producto: 'Producto C', cantidad: 2, total: 50000 },
  // Otras ventas...
];

export const getVentaById = async (id) => {
  try {
    // Simulamos una llamada a una API que devuelve la venta por su ID
    const venta = ventas.find(venta => venta.id === parseInt(id));
    if (!venta) {
      throw new Error('Venta no encontrada');
    }
    return venta;
  } catch (error) {
    throw new Error(`Error al obtener la venta: ${error.message}`);
  }
};

export const updateVenta = async (ventaActualizada) => {
  try {
    // Simulamos la actualización de la venta en la lista de ventas
    ventas = ventas.map(venta => {
      if (venta.id === ventaActualizada.id) {
        return { ...venta, producto: ventaActualizada.producto };
      }
      return venta;
    });
    // Simulamos una llamada a una API para actualizar la venta
    return true; // Devolvemos true para indicar que la actualización fue exitosa
  } catch (error) {
    throw new Error(`Error al actualizar la venta: ${error.message}`);
  }
};

const Ventas = () => {
  const [ventas, setVentas] = useState([]);

  useEffect(() => {
    // Lógica para obtener la lista de ventas
    // En este ejemplo, simularemos una llamada a una API para obtener las ventas
    // getVentaList().then(data => setVentas(data));
    // Aquí simplemente inicializamos con datos de ejemplo
    setVentas([
      { id: 1, producto: 'Producto A', cantidad: 5, total: 100000 },
      { id: 2, producto: 'Producto B', cantidad: 3, total: 75000 },
      { id: 3, producto: 'Producto C', cantidad: 2, total: 50000 },
      // Otras ventas...
    ]);
  }, []);

  // Función para actualizar una venta
  const handleUpdateVenta = async (ventaActualizada) => {
    try {
      await updateVenta(ventaActualizada);
      // Si la actualización es exitosa, actualizamos el estado de la venta
      setVentas(ventas.map(venta => {
        if (venta.id === ventaActualizada.id) {
          return ventaActualizada;
        }
        return venta;
      }));
      // Otra opción sería volver a obtener la lista de ventas desde la API para reflejar los cambios
    } catch (error) {
      console.error('Error al actualizar la venta:', error);
    }
  };

  // Función para eliminar una venta
  const handleDeleteVenta = (id) => {
    setVentas(ventas.filter(venta => venta.id !== id));
  };

  // Función para exportar a PDF
  const exportarPDF = (venta) => {
    const doc = new jsPDF();
    doc.text(`Producto: ${venta.producto}`, 10, 10);
    doc.text(`Cantidad: ${venta.cantidad}`, 10, 20);
    doc.text(`Total: ${venta.total}`, 10, 30);
    doc.save('venta.pdf');
  };

  return (
    <div className="ventas-container">
      <center><h1 style={{ fontFamily: 'Arial' }}>Ventas</h1></center><br/>
      <button><Link to="/home" style={{ textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{ fontFamily: 'Arial' }}>Producto</th>
            <th style={{ fontFamily: 'Arial' }}>Cantidad</th>
            <th style={{ fontFamily: 'Arial' }}>Total</th>
            <th style={{ fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {ventas.map(venta => (
            <tr key={venta.id}>
              <td>{venta.producto}</td>
              <td>{venta.cantidad}</td>
              <td>{venta.total}</td>
              <td>
                {/* Enlace a la página de edición de la venta */}
                <button><Link to={{
                  pathname: `/editar-venta/${venta.id}`,
                  state: { venta } // Pasamos el objeto de la venta como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar la venta */}
                <button onClick={() => handleDeleteVenta(venta.id)}>Eliminar</button>
                <button onClick={() => exportarPDF(venta)}>Exportar a PDF</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevaVenta */}
      <center><h1><Link to="/nueva-venta" className="link" style={{ color: 'black', textDecoration: 'none' }}>Agregar Venta</Link></h1></center>
    </div>
  );
};

export default Ventas;
