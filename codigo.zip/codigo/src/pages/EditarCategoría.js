import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getCategoryById, updateCategory } from './Categorías';
import './NuevaCategoría.css'

const EditarCategoría = () => {
  const { id } = useParams();
  const [categoria, setCategoria] = useState({ id: '', nombre: '' });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const categoriaData = await getCategoryById(id);
        setCategoria(categoriaData);
      } catch (error) {
        console.error('Error al obtener la categoría:', error);
      }
    };
    fetchData();
  }, [id]);

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      await updateCategory(categoria);
      // Actualizar el estado de la categoría de forma inmutable
      setCategoria(prevCategoria => ({
        ...prevCategoria,
        nombre: categoria.nombre // Actualizamos solo el nombre, ya que el ID no debería cambiar
      }));
      // Redireccionar a la página de categorías
      window.location.href = '/categorías';
    } catch (error) {
      console.error('Error al actualizar la categoría:', error);
    }
  };

  const handleInputChange = (e) => {
    setCategoria({ ...categoria, [e.target.name]: e.target.value });
  };

  return (
    <div className="Title">
    <center><h2 style={{fontFamily: 'Arial' }}>Editar Categoría</h2></center>
    <div className="card">
          <div className="card-header">
            <center><h3><p style={{fontFamily: 'Arial' }}>Ingrese Sus Datos:</p></h3></center>
          </div><br/><br/>
          <center><form className="was-validated">
      <div className="mb-3">
        <label htmlFor="código" className="form-label" style={{fontFamily: 'Arial' }}>ID Categoría: </label>
        <input type="text" name="código" value={categoria.id} onChange={handleInputChange} required /><br/><br/>
      </div>
      <div className="mb-3">
        <label htmlFor="nombre" className="form-label" style={{fontFamily: 'Arial' }}>Nombre Categoría: </label>
        <input type="text" name="nombre" value={categoria.nombre} onChange={handleInputChange} required /><br/><br/>
      </div>
      <div className="text-center">
        {/* Utiliza Link para redirigir a la página Home al hacer clic en el botón */}
        <button><Link to="/categorías" className="link" style={{ textDecoration: 'none', color: 'white' }}>Editar Categoría</Link></button>
      </div>
    </form></center>
        </div>
    </div>
  );
};

export default EditarCategoría;
