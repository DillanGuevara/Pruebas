import React from 'react';
import { Link } from 'react-router-dom';

export const EditarCliente = () => {
  return (
    <div className="Title">
    <center><h2 style={{ fontFamily: 'Arial' }}>Editar Clientes</h2></center>
    <div className="card">
          <div className="card-header">
            <center><h3><p style={{ fontFamily: 'Arial' }}>Ingrese Sus Datos:</p></h3></center>
          </div><br/><br/>
          <center><form className="was-validated">
      <div className="mb-3 mt-3">
        <label htmlFor="usuario" className="form-label" style={{ fontFamily: 'Arial' }}>ID: </label>
        <input type="text" className="form-control" id="ID" placeholder="Ingrese Su ID" name="ID" required /><br/><br/>
      </div>
      <div className="mb-3">
        <label htmlFor="select" className="form-label" style={{ fontFamily: 'Arial' }}>Tipo de documento: </label>
        <select id="select" required>
          <option value="">Selecciona...</option>
          <option value="RUES">RUES</option>
          <option value="RUT">RUT</option>
          <option value="NIT">NIT</option>
        </select><br/><br/>
      </div>
      <div className="mb-3">
        <label htmlFor="documento" className="form-label" style={{ fontFamily: 'Arial' }}>Número de documento: </label>
        <input type="text" className="form-control" id="documento" placeholder="Ingrese Su Número De Documento" name="documento" required /><br/><br/>
      </div>
      <div className="mb-3">
        <label htmlFor="nombre" className="form-label" style={{ fontFamily: 'Arial' }}>Nombre: </label>
        <input type="text" className="form-control" id="nombre" placeholder="Ingrese Su Nombre" name="nombre" required /><br/><br/>
      </div>
      <div className="mb-3">
        <label htmlFor="teléfono" className="form-label" style={{ fontFamily: 'Arial' }}>Teléfono: </label>
        <input type="text" className="form-control" id="teléfono" placeholder="Ingrese Su Teléfono" name="teléfono" required /><br/><br/>
      </div><br></br>
      <div className="text-center">
        {/* Utiliza Link para redirigir a la página Home al hacer clic en el botón */}
        <button><Link to="/clientes" className="link" style={{ textDecoration: 'none', color: 'white' }}>Editar Cliente</Link></button>
      </div>
    </form></center>
        </div>
    </div>
  )
}

export default EditarCliente;