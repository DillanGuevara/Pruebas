import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Categorías.css'; // Importar el archivo CSS para los estilos

// Supongamos que tienes una lista de categorías
let categorias = [
  { id: 1, nombre: 'Categoría 1' },
  { id: 2, nombre: 'Categoría 2' },
  // Otras categorías...
];

export const getCategoryById = async (id) => {
  try {
    // Simulamos una llamada a una API que devuelve la categoría por su ID
    const categoria = categorias.find(categoria => categoria.id === parseInt(id));
    if (!categoria) {
      throw new Error('Categoría no encontrada');
    }
    return categoria;
  } catch (error) {
    throw new Error(`Error al obtener la categoría: ${error.message}`);
  }
};

export const updateCategory = async (categoriaActualizada) => {
  try {
    // Simulamos la actualización de la categoría en la lista de categorías
    categorias = categorias.map(categoria => {
      if (categoria.id === categoriaActualizada.id) {
        return { ...categoria, nombre: categoriaActualizada.nombre };
      }
      return categoria;
    });
    // Simulamos una llamada a una API para actualizar la categoría
    return true; // Devolvemos true para indicar que la actualización fue exitosa
  } catch (error) {
    throw new Error(`Error al actualizar la categoría: ${error.message}`);
  }
};

const Categorias = () => {
  const [categorias, setCategorias] = useState([]);

  useEffect(() => {
    // Lógica para obtener la lista de categorías
    // En este ejemplo, simularemos una llamada a una API para obtener las categorías
    // getCategoryList().then(data => setCategorias(data));
    // Aquí simplemente inicializamos con datos de ejemplo
    setCategorias([
      { id: 1, nombre: 'Categoría 1' },
      { id: 2, nombre: 'Categoría 2' },
      // Otras categorías...
    ]);
  }, []);

  // Función para actualizar una categoría
  const handleUpdateCategory = async (categoriaActualizada) => {
    try {
      await updateCategory(categoriaActualizada);
      // Si la actualización es exitosa, actualizamos el estado de la categoría
      setCategorias(categorias.map(categoria => {
        if (categoria.id === categoriaActualizada.id) {
          return categoriaActualizada;
        }
        return categoria;
      }));
      // Otra opción sería volver a obtener la lista de categorías desde la API para reflejar los cambios
    } catch (error) {
      console.error('Error al actualizar la categoría:', error);
    }
  };

  // Función para eliminar una categoría
  const handleDeleteCategory = (id) => {
    setCategorias(categorias.filter(categoria => categoria.id !== id));
  };

  return (
    <div className="categorias-container">
      <center><h1 style={{fontFamily: 'Arial' }}>Categorías</h1></center><br/>
      <button><Link to="/home" style={{textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{fontFamily: 'Arial' }}>Nombre</th>
            <th style={{fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {categorias.map(categoria => (
            <tr key={categoria.id}>
              <td>{categoria.nombre}</td>
              <td>
                {/* Enlace a la página de edición de la categoría */}
                <button><Link to={{
                  pathname: `/editar-categoria/${categoria.id}`,
                  state: { categoria } // Pasamos el objeto de la categoría como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar la categoría */}
                <button onClick={() => handleDeleteCategory(categoria.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevaCategoría */}
      <center><h1><Link to="/nueva-categoria" className="link" style={{ color: 'black', textDecoration: 'none' }}>Agregar Categoría</Link></h1></center>
    </div>
  );
};

export default Categorias;
