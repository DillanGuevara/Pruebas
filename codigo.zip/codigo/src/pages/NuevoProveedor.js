import React, { useState } from 'react';
import './NuevoProveedor.css'; // Importar el archivo CSS para los estilos
import { Link } from 'react-router-dom';

const NuevoProveedor = ({ onAddProveedor, redirectToProveedores, setProveedores }) => {
  const [nombre, setNombre] = useState('');
  const [contacto, setContacto] = useState('');
  const [estado, setEstado] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const nuevoProveedor = {
        id: Math.floor(Math.random() * 1000) + 1, // Generar un ID único
        nombre: nombre,
        contacto: contacto,
        estado: estado
      };
      await onAddProveedor(nuevoProveedor);
      setProveedores(prevProveedores => [...prevProveedores, nuevoProveedor]); // Actualizar la lista de proveedores
      setNombre('');
      setContacto('');
      setEstado('');
      redirectToProveedores(); // Redirigir a la página de proveedores
    } catch (error) {
      console.error('Error al agregar el proveedor:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case 'nombre':
        setNombre(value);
        break;
      case 'contacto':
        setContacto(value);
        break;
      case 'estado':
        setEstado(value);
        break;
      default:
        break;
    }
  };

  return (
    <div className="nuevo-proveedor-container">
      <h2 className="title">Nuevo Proveedor</h2>
      <form onSubmit={handleFormSubmit}>
        <div className="form-group">
          <label className="label">Nombre:</label>
          <input type="text" name="nombre" value={nombre} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Contacto:</label>
          <input type="text" name="contacto" value={contacto} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Estado:</label>
          <input type="text" name="estado" value={estado} onChange={handleInputChange} className="input" />
        </div>
        <center><button type="submit" className="button"><Link to="/proveedores" style={{ textDecoration: 'none', color: 'white' }}>Agregar</Link></button></center>
      </form>
    </div>
  );
};

export default NuevoProveedor;
