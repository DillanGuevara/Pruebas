import React, { useState } from 'react';
import './NuevaCategoría.css'; // Importar el archivo CSS

const NuevaCategoría = ({ onAddCategoria, redirectToCategorias, setCategorias }) => {
  const [nombre, setNombre] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const nuevaCategoria = {
        id: Math.floor(Math.random() * 1000) + 1, // Generar un ID único
        nombre: nombre
      };
      await onAddCategoria(nuevaCategoria);
      setCategorias(prevCategorias => [...prevCategorias, nuevaCategoria]); // Actualizar la lista de categorías
      setNombre('');
      redirectToCategorias(); // Redirigir a la página de categorías
    } catch (error) {
      console.error('Error al agregar la categoría:', error);
    }
  };

  const handleInputChange = (e) => {
    setNombre(e.target.value);
  };

  return (
    <div className="container">
      <div className="form-container">
        <h2>Nueva Categoría</h2>
        <form onSubmit={handleFormSubmit}>
          <label>Nombre:</label>
          <input type="text" value={nombre} onChange={handleInputChange} />
          <button type="submit">Agregar</button>
        </form>
      </div>
    </div>
  );
};

export default NuevaCategoría;
