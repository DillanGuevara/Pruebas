import React, { useState, useEffect } from "react";
import "./Home.css";
import Sidebar from "../components/Sidebar";
import { Link } from "react-router-dom";
import { Table } from "reactstrap";

function Home() {
  const [usuario, setUsuario] = useState("Admin Dillan");
  const [ventas, setVentas] = useState(30000);
  const [productos, setProductos] = useState(3);
  const [clientes, setClientes] = useState(35000);
  const [compras, setCompras] = useState(7);
  const [categorías, setCategorias] = useState(2);
  const [marcas, setMarcas] = useState(2);
  const [clientesNuevos, setClientesNuevos] = useState(0);

  useEffect(() => {
    // Simular la carga de datos
    setTimeout(() => {
      setVentas(30000 + Math.floor(Math.random() * 1000));
      setProductos(3 + Math.floor(Math.random() * 5));
      setClientes(35000 + Math.floor(Math.random() * 1000));
      setCompras(7 + Math.floor(Math.random() * 3));
      setCategorias(2 + Math.floor(Math.random() * 1));
      setMarcas(2 + Math.floor(Math.random() * 1));
      setClientesNuevos(clientesNuevos + Math.floor(Math.random() * 5));
    }, 1000);
  }, []);

  return (
    <div className="Home">
      <Sidebar />
      <header className="Home-header">
      </header>
      <main className="Home-main">
        <section className="Home-seccion-izquierda">
          {/* Contenido de la sección izquierda */}
        </section>
        <section className="Home-seccion-derecha">
          <center><h1>Bienvenido, {usuario}!</h1></center>
          <h2>Detalles</h2>
          <div className="Home-grid-container">
            <div className="Home-fila">
              <div className="Home-cuadro">
                <p>{clientes}</p>
                <p>Clientes </p>
              </div>
              <div className="Home-cuadro">
                <p>{ventas}</p>
                <p>Ventas</p>
              </div>
              <div className="Home-cuadro">
                <p>{productos}</p>
                <p>Productos </p>
              </div>
            </div>
            <div className="Home-fila">
              <div className="Home-cuadro">
                <p>{compras}</p>
                <p>Compras </p>
              </div>
              <div className="Home-cuadro">
                <p>{categorías}</p>
                <p>Categorías </p>
              </div>
              <div className="Home-cuadro">
                <p>{marcas}</p>
                <p>Marcas</p>
              </div>
            </div>
          </div>
          <br/><br/>
          <center>
            <Link to="/nuevo-cliente" className="link" style={{ textDecoration: 'none', color: 'black' }}><h1>Clientes Nuevos</h1></Link>
          </center>
          <br/><br/>
          <center><Table className="Table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Tipo de documento</th>
                <th>Número de documento</th>
                <th>Teléfono</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>ETB</td>
                <td>NIT</td>
                <td>3434248291</td>
                <td>4349473847</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Claro</td>
                <td>RUT</td>
                <td>4545326171</td>
                <td>3461961966</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Movistar</td>
                <td>RUES</td>
                <td>2892510591</td>
                <td>4566490290</td>
              </tr>
            </tbody>
          </Table>
          </center>
        </section>
      </main>
    </div>
  );
}

export default Home;
