import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export const EditarProducto = () => {
  const [producto, setProducto] = useState({
    id: '',
    nombre: '',
    categoria: '',
    precio: '',
    stock: '',
    estado: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProducto({
      ...producto,
      [name]: value
    });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    // Aquí puedes manejar la lógica para editar el producto
  };

  return (
    <div className="Title">
      <center><h2 style={{ fontFamily: 'Arial' }}>Editar Producto</h2></center>
      <div className="card">
        <div className="card-header">
          <center><h3><p style={{ fontFamily: 'Arial' }}>Ingrese Sus Datos:</p></h3></center>
        </div><br /><br />
        <center>
          <form className="was-validated" onSubmit={handleFormSubmit}>
            <div className="mb-3">
              <label htmlFor="id" className="form-label" style={{ fontFamily: 'Arial' }}>Código producto: </label>
              <input type="text" name="id" value={producto.id} onChange={handleInputChange} required /><br /><br />
            </div>
            <div className="mb-3">
              <label htmlFor="nombre" className="form-label" style={{ fontFamily: 'Arial' }}>Nombre producto: </label>
              <input type="text" name="nombre" value={producto.nombre} onChange={handleInputChange} required /><br/><br/>
            </div>
            <div className="mb-3">
              <label htmlFor="categoria" className="form-label" style={{fontFamily: 'Arial' }}>Categoría: </label>
              <input type="text" name="categoria" value={producto.categoria} onChange={handleInputChange} required /><br/><br/>
            </div>
            <div className="mb-3">
              <label htmlFor="precio" className="form-label" style={{fontFamily: 'Arial' }}>Precio: </label>
              <input type="text" name="precio" value={producto.precio} onChange={handleInputChange} required /><br/><br/>
            </div>
            <div className="mb-3">
              <label htmlFor="stock" className="form-label" style={{fontFamily: 'Arial' }}>Stock: </label>
              <input type="text" name="stock" value={producto.stock} onChange={handleInputChange} required /><br/><br/>
            </div>
            <div className="mb-3">
              <label htmlFor="estado" className="form-label" style={{fontFamily: 'Arial' }}>Estado: </label>
              <input type="text" name="estado" value={producto.estado} onChange={handleInputChange} required /><br/><br/>
            </div><br></br>
            <div className="text-center">
              <button type="submit" className="link" style={{ textDecoration: 'none', color: 'white' }}><Link to="/productos" style={{ textDecoration: 'none', color: 'white' }}>Editar producto</Link></button>
            </div>
          </form>
        </center>
      </div>
    </div>
  );
}

export default EditarProducto;
