import React, { useState } from 'react';
import './NuevoProducto.css'; // Importar el archivo CSS para los estilos

const NuevoProducto = ({ onAddProducto, redirectToProductos, setProductos }) => {
  const [nombre, setNombre] = useState('');
  const [categoría, setCategoria] = useState('');
  const [precio, setPrecio] = useState(0);
  const [stock, setStock] = useState(0);
  const [estado, setEstado] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const nuevoProducto = {
        id: Math.floor(Math.random() * 1000) + 1, // Generar un ID único
        nombre: nombre,
        categoría: categoría,
        precio: precio,
        stock: stock,
        estado: estado
      };
      await onAddProducto(nuevoProducto);
      setProductos(prevProductos => [...prevProductos, nuevoProducto]); // Actualizar la lista de productos
      setNombre('');
      setCategoria('');
      setPrecio(0);
      setStock(0);
      setEstado('');
      redirectToProductos(); // Redirigir a la página de productos
    } catch (error) {
      console.error('Error al agregar el producto:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case 'nombre':
        setNombre(value);
        break;
      case 'categoría':
        setCategoria(value);
        break;
      case 'precio':
        setPrecio(parseFloat(value));
        break;
      case 'stock':
        setStock(parseInt(value));
        break;
      case 'estado':
        setEstado(value);
        break;
      default:
        break;
    }
  };

  return (
    <div className="nuevo-producto-container">
      <h2 className="title">Nuevo Producto</h2>
      <form onSubmit={handleFormSubmit}>
        <div className="form-group">
          <label className="label">Nombre:</label>
          <input type="text" name="nombre" value={nombre} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Categoría:</label>
          <input type="text" name="categoría" value={categoría} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Precio:</label>
          <input type="number" name="precio" value={precio} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Stock:</label>
          <input type="number" name="stock" value={stock} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Estado:</label>
          <input type="text" name="estado" value={estado} onChange={handleInputChange} className="input" />
        </div>
        <center><button type="submit" className="button">Agregar</button></center>
      </form>
    </div>
  );
};

export default NuevoProducto;
