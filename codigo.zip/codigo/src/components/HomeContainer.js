// HomeContainer.js
import React from 'react';
import Home from '../pages/Home'; 

function HomeContainer() {
  return (
    <div>
      <Home /> {/* Renderiza la página Home */}
    </div>
  );
}

export default HomeContainer;
