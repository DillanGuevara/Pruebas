import React from 'react';
import { Link } from 'react-router-dom'; 
import './Login.css'; 

function Login() {
  return (
    <div className="login">
      <h2>¡Bienvenido!</h2>
      <div className="container mt-3">
        <div className="card">
          <div className="card-header">
            <h3><p>Ingrese Sus Datos:</p></h3>
          </div><br/><br/>
          <form className="was-validated">
            <div className="mb-3 mt-3">
              <label htmlFor="usuario" className="form-label">Usuario: </label>
              <input type="text" className="form-control" id="usuario" placeholder="Ingrese Su Usuario" name="usuario" required /><br/><br/>
            </div>
            <div className="mb-3">
              <label htmlFor="contraseña" className="form-label">Contraseña: </label>
              <input type="password" className="form-control" id="contraseña" placeholder="Ingrese Su Contraseña" name="contraseña" required />
            </div><br></br>
            <div className="text-center">
              {/* Utiliza Link para redirigir a la página Home al hacer clic en el botón */}
              <center><button><Link to="/home" className="link" style={{ textDecoration: 'none', color: 'white' }}>Ingresar</Link></button></center><br></br>
              <center><Link to="/registro" className="link" style={{ textDecoration: 'none', color: 'blue' }}>¿Eres un Admin Nuevo?</Link></center>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
