// EditarCategoria.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EditarCategoria = ({ match }) => {
  const [categoria, setCategoria] = useState(null);
  const [nombre, setNombre] = useState('');

  useEffect(() => {
    const fetchCategoria = async () => {
      try {
        const response = await axios.get(`${API_URL}/categorias/${match.params.id}`);
        setCategoria(response.data);
        setNombre(response.data.nombre);
      } catch (error) {
        console.error('Error al obtener la categoría:', error);
      }
    };

    fetchCategoria();
  }, [match.params.id]);

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.put(`${API_URL}/categorias/${categoria.id}`, { nombre });
      console.log('Categoría actualizada:', response.data);
      // Aquí podrías redirigir al usuario a la página de Categorias.js
    } catch (error) {
      console.error('Error al actualizar la categoría:', error);
    }
  };

  if (!categoria) {
    return <div>Cargando...</div>;
  }

  return (
    <div>
      <h1>Editar Categoría</h1>
      <form onSubmit={handleFormSubmit}>
        <label>
          Nombre:
          <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} />
        </label>
        <button type="submit">Guardar Cambios</button>
      </form>
    </div>
  );
};

export default EditarCategoria;

export const API_URL = 'http://localhost:8000/api';
