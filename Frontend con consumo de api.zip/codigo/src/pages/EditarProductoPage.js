// EditarProductoPage.js
import React from 'react';
import { useParams } from 'react-router-dom';
import EditarProducto from './EditarProducto';

const EditarProductoPage = () => {
  const { id } = useParams(); // Obtiene el ID del producto de la URL
  return (
    <div>
      <h1>Editar Producto</h1>
      <EditarProducto id={id} />
    </div>
  );
};

export default EditarProductoPage;
