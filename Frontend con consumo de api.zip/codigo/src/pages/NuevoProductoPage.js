// NuevoProductoPage.js
import React from 'react';
import NuevoProducto from './NuevoProducto';

const NuevoProductoPage = () => {
  return (
    <div>
      <h1>Nuevo Producto</h1>
      <NuevoProducto />
    </div>
  );
};

export default NuevoProductoPage;
