import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Categorías.css';
import axios from 'axios';
import { API_URL } from '../config';

const Categorias = () => {
  const [categorias, setCategorias] = useState([]);

  axios.post('/user', {
    firstName: 'Fred',
    lastName: 'Flintstone'
  })
  .then(function (response) {
    console.log(response);
  })
  .catch(function (error) {
    console.log(error);
  });

  useEffect(() => {
    const obtenerCategorias = async () => {
      try {
        const response = await axios.get(`${API_URL}/categorias`);
        setCategorias(response.data);
      } catch (error) {
        console.error('Error al obtener categorías:', error);
      }
    };

    obtenerCategorias();
  }, []);

  // Función para eliminar una categoría
  const handleDeleteCategory = async (id) => {
    try {
      // Aquí deberías realizar una llamada a la API para eliminar la categoría
      // Por ejemplo:
      await axios.delete(`${API_URL}/categorias/${id}`);
      // Actualizamos el estado eliminando la categoría de la lista
      setCategorias(categorias.filter(categoria => categoria.id !== id));
    } catch (error) {
      console.error('Error al eliminar la categoría:', error);
    }
  };

  return (
    <div className="categorias-container">
      <center><h1 style={{fontFamily: 'Arial' }}>Categorías</h1></center><br/>
      <button><Link to="/home" style={{textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{fontFamily: 'Arial' }}>Nombre</th>
            <th style={{fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {categorias.map(categoria => (
            <tr key={categoria.id}>
              <td>{categoria.nombre}</td>
              <td>
                {/* Enlace a la página de edición de la categoría */}
                <button><Link to={{
                  pathname: `/editar-categoria/${categoria.id}`,
                  state: { categoria } // Pasamos el objeto de la categoría como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar la categoría */}
                <button onClick={() => handleDeleteCategory(categoria.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevaCategoría */}
      <center><h1><Link to="/nueva-categoria" className="link" style={{ color: 'black', textDecoration: 'none' }}>Agregar Categoría</Link></h1></center>
    </div>
  );
};

export default Categorias;
