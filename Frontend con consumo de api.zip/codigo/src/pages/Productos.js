// Productos.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NuevoProducto from './NuevoProducto';
import EditarProducto from './EditarProducto';
import { Link } from 'react-router-dom';

const Productos = () => {
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    obtenerProductos();
  }, []);

  const obtenerProductos = async () => {
    try {
      const response = await axios.get('http://localhost:8000/api/productos');
      setProductos(response.data);
    } catch (error) {
      console.error('Error al obtener productos:', error);
    }
  };

  const handleAgregarProducto = (nuevoProducto) => {
    setProductos([...productos, nuevoProducto]);
  };

  const handleEditarProducto = (productoEditado) => {
    setProductos(productos.map(producto => producto.id === productoEditado.id ? productoEditado : producto));
  };

  const handleEliminarProducto = async (id) => {
    try {
      await axios.delete(`http://localhost:8000/api/productos/${id}`);
      setProductos(productos.filter(producto => producto.id !== id));
    } catch (error) {
      console.error('Error al eliminar producto:', error);
    }
  };

  return (
    <div>
      <NuevoProducto onAddProducto={handleAgregarProducto} />
      <center><h1 style={{fontFamily: 'Arial'}}>Productos</h1></center><br/>
      <table>
        <thead>
          <tr>
            <th style={{fontFamily: 'Arial'}}>Nombre</th>
            <th style={{fontFamily: 'Arial'}}>Categoría</th>
            <th style={{fontFamily: 'Arial'}}>Precio</th>
            <th style={{fontFamily: 'Arial'}}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {productos.map(producto => (
            <tr key={producto.id}>
              <td>{producto.nombre}</td>
              <td>{producto.categoria}</td>
              <td>{producto.precio}</td>
              <td>
                <button onClick={() => handleEliminarProducto(producto.id)}>Eliminar</button>
                <EditarProducto producto={producto} onEditProducto={handleEditarProducto} />
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>

      <center><button><Link to='/home' style={{textDecoration: 'none', color: 'white'}}>Ir a Inicio</Link></button></center>

    </div>

  );
};

export default Productos;
