// NuevaCategoria.js
import React, { useState } from 'react';
import axios from 'axios';
import { Navigate } from 'react-router-dom'; // Importar Navigate desde react-router-dom

const NuevaCategoria = () => {
  const [nombre, setNombre] = useState('');
  const [navigate, setNavigate] = useState(false); // Estado para la redirección

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API_URL}/categorias`, { nombre });
      console.log('Nueva categoría creada:', response.data);
      setNavigate(true); // Establecer el estado de redirección a true
    } catch (error) {
      console.error('Error al crear nueva categoría:', error);
    }
  };

  // Si navigate es true, redirigir al usuario a la página de Categorias.js
  if (navigate) {
    return <Navigate to="/categorías" />; // Utilizar Navigate desde react-router-dom
  }

  return (
    <div>
      <h1>Nueva Categoría</h1>
      <form onSubmit={handleFormSubmit}>
        <label>
          Nombre:
          <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} />
        </label>
        <button type="submit">Guardar</button>
      </form>
    </div>
  );
};

export default NuevaCategoria;

export const API_URL = 'http://localhost:8000/api/categorias';
