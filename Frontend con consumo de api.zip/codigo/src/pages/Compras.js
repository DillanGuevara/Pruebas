import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import jsPDF from 'jspdf';
import axios from 'axios';

const getCompras = async () => {
  const response = await axios.get(`${API_URL}/compras`);
  const compras = response.data;
  return compras;
};

// Supongamos que tienes una lista de compras
let compras = [
  { id: 1, producto: 'Producto X', cantidad: 2, total: 150 },
  { id: 2, producto: 'Producto Y', cantidad: 1, total: 50 },
  { id: 3, producto: 'Producto Z', cantidad: 3, total: 200 },
  // Otras compras...
];

export const getCompraById = async (id) => {
  try {
    // Simulamos una llamada a una API que devuelve la compra por su ID
    const compra = compras.find(compra => compra.id === parseInt(id));
    if (!compra) {
      throw new Error('Compra no encontrada');
    }
    return compra;
  } catch (error) {
    throw new Error(`Error al obtener la compra: ${error.message}`);
  }
};

export const updateCompra = async (compraActualizada) => {
  try {
    // Simulamos la actualización de la compra en la lista de compras
    compras = compras.map(compra => {
      if (compra.id === compraActualizada.id) {
        return { ...compra, producto: compraActualizada.producto };
      }
      return compra;
    });
    // Simulamos una llamada a una API para actualizar la compra
    return true; // Devolvemos true para indicar que la actualización fue exitosa
  } catch (error) {
    throw new Error(`Error al actualizar la compra: ${error.message}`);
  }
};

const Compras = () => {
  const [compras, setCompras] = useState([]);

  useEffect(() => {
    // Lógica para obtener la lista de compras
    // En este ejemplo, simularemos una llamada a una API para obtener las compras
    // getCompraList().then(data => setCompras(data));
    // Aquí simplemente inicializamos con datos de ejemplo
    setCompras([
      { id: 1, producto: 'Producto X', cantidad: 2, total: 150000 },
      { id: 2, producto: 'Producto Y', cantidad: 1, total: 50000 },
      { id: 3, producto: 'Producto Z', cantidad: 3, total: 200000 },
      // Otras compras...
    ]);
  }, []);

  // Función para actualizar una compra
  const handleUpdateCompra = async (compraActualizada) => {
    try {
      await updateCompra(compraActualizada);
      // Si la actualización es exitosa, actualizamos el estado de la compra
      setCompras(compras.map(compra => {
        if (compra.id === compraActualizada.id) {
          return compraActualizada;
        }
        return compra;
      }));
      // Otra opción sería volver a obtener la lista de compras desde la API para reflejar los cambios
    } catch (error) {
      console.error('Error al actualizar la compra:', error);
    }
  };

  // Función para eliminar una compra
  const handleDeleteCompra = (id) => {
    setCompras(compras.filter(compra => compra.id !== id));
  };

  // Función para exportar a PDF
  const exportarPDF = (compra) => {
    const doc = new jsPDF();
    doc.text(`Producto: ${compra.producto}`, 10, 10);
    doc.text(`Cantidad: ${compra.cantidad}`, 10, 20);
    doc.text(`Total: ${compra.total}`, 10, 30);
    doc.save('compra.pdf');
  };

  return (
    <div className="compras-container">
      <center><h1 style={{ fontFamily: 'Arial' }}>Compras</h1></center><br/>
      <button><Link to="/home" style={{ textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{ fontFamily: 'Arial' }}>Producto</th>
            <th style={{ fontFamily: 'Arial' }}>Cantidad</th>
            <th style={{ fontFamily: 'Arial' }}>Total</th>
            <th style={{ fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {compras.map(compra => (
            <tr key={compra.id}>
              <td>{compra.producto}</td>
              <td>{compra.cantidad}</td>
              <td>{compra.total}</td>
              <td>
                {/* Enlace a la página de edición de la compra */}
                <button><Link to={{
                  pathname: `/editar-compra/${compra.id}`,
                  state: { compra } // Pasamos el objeto de la compra como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar la compra */}
                <button onClick={() => handleDeleteCompra(compra.id)}>Eliminar</button>
                <button onClick={() => exportarPDF(compra)}>Exportar a PDF</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevaCompra */}
      <center><h1><Link to="/nueva-compra" className="link" style={{ color: 'black', textDecoration: 'none' }}>Agregar Compra</Link></h1></center>
    </div>
  );
};

export default Compras;

export const API_URL = 'http://localhost:3000/api'; // Replace with your actual API URL
