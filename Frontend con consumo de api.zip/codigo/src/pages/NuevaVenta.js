import React, { useState } from 'react';
import './NuevaVenta.css'; // Importar el archivo CSS para los estilos
import { Link } from 'react-router-dom';

const NuevaVenta = ({ onAddVenta, redirectToVentas, setVentas }) => {
  const [producto, setProducto] = useState('');
  const [cantidad, setCantidad] = useState('');
  const [total, setTotal] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const nuevaVenta = {
        id: Math.floor(Math.random() * 1000) + 1, // Generar un ID único
        producto: producto,
        cantidad: parseInt(cantidad),
        total: parseFloat(total)
      };
      await onAddVenta(nuevaVenta);
      setVentas(prevVentas => [...prevVentas, nuevaVenta]); // Actualizar la lista de ventas
      setProducto('');
      setCantidad('');
      setTotal('');
      redirectToVentas(); // Redirigir a la página de ventas
    } catch (error) {
      console.error('Error al agregar la venta:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case 'producto':
        setProducto(value);
        break;
      case 'cantidad':
        setCantidad(value);
        break;
      case 'total':
        setTotal(value);
        break;
      default:
        break;
    }
  };

  return (
    <div className="nueva-venta-container">
      <h2 className="title">Nueva Venta</h2>
      <form onSubmit={handleFormSubmit}>
        <div className="form-group">
          <label className="label">Producto:</label>
          <input type="text" name="producto" value={producto} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Cantidad:</label>
          <input type="number" name="cantidad" value={cantidad} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Total:</label>
          <input type="number" name="total" value={total} onChange={handleInputChange} className="input" />
        </div>
        <center><button type="submit" className="button"><Link to="/ventas" style={{ textDecoration: 'none', color: 'white' }}>Agregar</Link></button></center>
      </form>
    </div>
  );
};

export default NuevaVenta;
