import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const getProveedores = async () => {
  const response = await axios.get(`${API_URL}/proveedores`);
  const proveedores = response.data;
  return proveedores;
};

// Supongamos que tienes una lista de proveedores
let proveedores = [
  { id: 1, nombre: 'Proveedor A', contacto: 'Contacto A', estado: 'Activo' },
  { id: 2, nombre: 'Proveedor B', contacto: 'Contacto B', estado: 'Inactivo' },
  { id: 3, nombre: 'Proveedor C', contacto: 'Contacto C', estado: 'Activo' },
  // Otros proveedores...
];

export const getProveedorById = async (id) => {
  try {
    // Simulamos una llamada a una API que devuelve el proveedor por su ID
    const proveedor = proveedores.find(proveedor => proveedor.id === parseInt(id));
    if (!proveedor) {
      throw new Error('Proveedor no encontrado');
    }
    return proveedor;
  } catch (error) {
    throw new Error(`Error al obtener el proveedor: ${error.message}`);
  }
};

export const updateProveedor = async (proveedorActualizado) => {
  try {
    // Simulamos la actualización del proveedor en la lista de proveedores
    proveedores = proveedores.map(proveedor => {
      if (proveedor.id === proveedorActualizado.id) {
        return { ...proveedor, nombre: proveedorActualizado.nombre };
      }
      return proveedor;
    });
    // Simulamos una llamada a una API para actualizar el proveedor
    return true; // Devolvemos true para indicar que la actualización fue exitosa
  } catch (error) {
    throw new Error(`Error al actualizar el proveedor: ${error.message}`);
  }
};

const Proveedores = () => {
  const [proveedores, setProveedores] = useState([]);

  useEffect(() => {
    // Lógica para obtener la lista de proveedores
    // En este ejemplo, simularemos una llamada a una API para obtener los proveedores
    // getProveedorList().then(data => setProveedores(data));
    // Aquí simplemente inicializamos con datos de ejemplo
    setProveedores([
      { id: 1, nombre: 'Proveedor A', contacto: 'Contacto A', estado: 'Activo' },
      { id: 2, nombre: 'Proveedor B', contacto: 'Contacto B', estado: 'Inactivo' },
      { id: 3, nombre: 'Proveedor C', contacto: 'Contacto C', estado: 'Activo' },
      // Otros proveedores...
    ]);
  }, []);

  // Función para actualizar un proveedor
  const handleUpdateProveedor = async (proveedorActualizado) => {
    try {
      await updateProveedor(proveedorActualizado);
      // Si la actualización es exitosa, actualizamos el estado del proveedor
      setProveedores(proveedores.map(proveedor => {
        if (proveedor.id === proveedorActualizado.id) {
          return proveedorActualizado;
        }
        return proveedor;
      }));
      // Otra opción sería volver a obtener la lista de proveedores desde la API para reflejar los cambios
    } catch (error) {
      console.error('Error al actualizar el proveedor:', error);
    }
  };

  // Función para eliminar un proveedor
  const handleDeleteProveedor = (id) => {
    setProveedores(proveedores.filter(proveedor => proveedor.id !== id));
  };

  return (
    <div className="proveedores-container">
      <center><h1 style={{ fontFamily: 'Arial' }}>Proveedores</h1></center><br/>
      <button><Link to="/home" style={{ textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{ fontFamily: 'Arial' }}>Nombre</th>
            <th style={{ fontFamily: 'Arial' }}>Contacto</th>
            <th style={{ fontFamily: 'Arial' }}>Estado</th>
            <th style={{ fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {proveedores.map(proveedor => (
            <tr key={proveedor.id}>
              <td>{proveedor.nombre}</td>
              <td>{proveedor.contacto}</td>
              <td>{proveedor.estado}</td>
              <td>
                {/* Enlace a la página de edición del proveedor */}
                <button><Link to={{
                  pathname: `/editar-proveedor/${proveedor.id}`,
                  state: { proveedor } // Pasamos el objeto del proveedor como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar el proveedor */}
                <button onClick={() => handleDeleteProveedor(proveedor.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevoProveedor */}
      <center><h1><Link to="/nuevo-proveedor" className="link" style={{ color: 'black', textDecoration: 'none' }}>Agregar Proveedor</Link></h1></center>
    </div>
  );
};

export default Proveedores;

export const API_URL = 'http://localhost:3000/api'; // Replace with your actual API URL
