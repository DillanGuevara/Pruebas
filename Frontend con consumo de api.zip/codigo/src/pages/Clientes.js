import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const getClientes = async () => {
  const response = await axios.get(`${API_URL}/clientes`);
  const clientes = response.data;
  return clientes;
};

// Supongamos que tienes una lista de clientes
let clientes = [
  { id: 1, nombre: 'Cliente A', contacto: 'Contacto A', estado: 'Activo' },
  { id: 2, nombre: 'Cliente B', contacto: 'Contacto B', estado: 'Inactivo' },
  { id: 3, nombre: 'Cliente C', contacto: 'Contacto C', estado: 'Activo' },
  // Otros clientes...
];

export const getClienteById = async (id) => {
  try {
    // Simulamos una llamada a una API que devuelve el cliente por su ID
    const cliente = clientes.find(cliente => cliente.id === parseInt(id));
    if (!cliente) {
      throw new Error('Cliente no encontrado');
    }
    return cliente;
  } catch (error) {
    throw new Error(`Error al obtener el cliente: ${error.message}`);
  }
};

export const updateCliente = async (clienteActualizado) => {
  try {
    // Simulamos la actualización del cliente en la lista de clientes
    clientes = clientes.map(cliente => {
      if (cliente.id === clienteActualizado.id) {
        return { ...cliente, nombre: clienteActualizado.nombre };
      }
      return cliente;
    });
    // Simulamos una llamada a una API para actualizar el cliente
    return true; // Devolvemos true para indicar que la actualización fue exitosa
  } catch (error) {
    throw new Error(`Error al actualizar el cliente: ${error.message}`);
  }
};

const Clientes = () => {
  const [clientes, setClientes] = useState([]);

  useEffect(() => {
    // Lógica para obtener la lista de clientes
    // En este ejemplo, simularemos una llamada a una API para obtener los clientes
    // getClienteList().then(data => setClientes(data));
    // Aquí simplemente inicializamos con datos de ejemplo
    setClientes([
      { id: 1, nombre: 'Cliente A', contacto: 'Contacto A', estado: 'Activo' },
      { id: 2, nombre: 'Cliente B', contacto: 'Contacto B', estado: 'Inactivo' },
      { id: 3, nombre: 'Cliente C', contacto: 'Contacto C', estado: 'Activo' },
      // Otros clientes...
    ]);
  }, []);

  // Función para actualizar un cliente
  const handleUpdateCliente = async (clienteActualizado) => {
    try {
      await updateCliente(clienteActualizado);
      // Si la actualización es exitosa, actualizamos el estado del cliente
      setClientes(clientes.map(cliente => {
        if (cliente.id === clienteActualizado.id) {
          return clienteActualizado;
        }
        return cliente;
      }));
      // Otra opción sería volver a obtener la lista de clientes desde la API para reflejar los cambios
    } catch (error) {
      console.error('Error al actualizar el cliente:', error);
    }
  };

  // Función para eliminar un cliente
  const handleDeleteCliente = (id) => {
    setClientes(clientes.filter(cliente => cliente.id !== id));
  };

  return (
    <div className="clientes-container">
      <center><h1 style={{ fontFamily: 'Arial' }}>Clientes</h1></center><br/>
      <button><Link to="/home" style={{ textDecoration: 'none', color: 'white' }}>Ir a inicio</Link></button><br/><br/>
      <table>
        <thead>
          <tr>
            <th style={{ fontFamily: 'Arial' }}>Nombre</th>
            <th style={{ fontFamily: 'Arial' }}>Contacto</th>
            <th style={{ fontFamily: 'Arial' }}>Estado</th>
            <th style={{ fontFamily: 'Arial' }}>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {clientes.map(cliente => (
            <tr key={cliente.id}>
              <td>{cliente.nombre}</td>
              <td>{cliente.contacto}</td>
              <td>{cliente.estado}</td>
              <td>
                {/* Enlace a la página de edición del cliente */}
                <button><Link to={{
                  pathname: `/editar-cliente/${cliente.id}`,
                  state: { cliente } // Pasamos el objeto del cliente como estado de la ubicación
                }} className="link" style={{ color: 'white', textDecoration: 'none' }}>Editar</Link></button>
                {/* Botón para eliminar el cliente */}
                <button onClick={() => handleDeleteCliente(cliente.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/>
      {/* Botón para ir a la página de NuevoCliente */}
      <center><h1><Link to="/nuevo-cliente" className="link" style={{ textDecoration: 'none', color: 'black' }}>Agregar Cliente</Link></h1></center>
    </div>
  );
};

export default Clientes;

export const API_URL = 'http://localhost:8000/api';
