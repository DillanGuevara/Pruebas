import React, { useState } from 'react';
import './NuevoCliente.css'; // Importar el archivo CSS para los estilos
import { Link } from 'react-router-dom';

const NuevoCliente = ({ onAddCliente, redirectToClientes, setClientes }) => {
  const [nombre, setNombre] = useState('');
  const [contacto, setContacto] = useState('');
  const [estado, setEstado] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const nuevoCliente = {
        id: Math.floor(Math.random() * 1000) + 1, // Generar un ID único
        nombre: nombre,
        contacto: contacto,
        estado: estado
      };
      await onAddCliente(nuevoCliente);
      setClientes(prevClientes => [...prevClientes, nuevoCliente]); // Actualizar la lista de clientes
      setNombre('');
      setContacto('');
      setEstado('');
      redirectToClientes(); // Redirigir a la página de clientes
    } catch (error) {
      console.error('Error al agregar el cliente:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case 'nombre':
        setNombre(value);
        break;
      case 'contacto':
        setContacto(value);
        break;
      case 'estado':
        setEstado(value);
        break;
      default:
        break;
    }
  };

  return (
    <div className="nuevo-cliente-container">
      <h2 className="title">Nuevo Cliente</h2>
      <form onSubmit={handleFormSubmit}>
        <div className="form-group">
          <label className="label">Nombre:</label>
          <input type="text" name="nombre" value={nombre} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Contacto:</label>
          <input type="text" name="contacto" value={contacto} onChange={handleInputChange} className="input" />
        </div>
        <div className="form-group">
          <label className="label">Estado:</label>
          <input type="text" name="estado" value={estado} onChange={handleInputChange} className="input" />
        </div>
        <center><button type="submit" className="button"><Link to="/clientes" style={{ textDecoration: 'none', color: 'white' }}>Agregar</Link></button></center>
      </form>
    </div>
  );
};

export default NuevoCliente;
