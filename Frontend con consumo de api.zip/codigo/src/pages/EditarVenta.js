import React from 'react';
import { Link } from 'react-router-dom';

export const EditarVenta = () => {
  return (
    <div className="Title">
      <center><h2 style={{ fontFamily: 'Arial' }}>Editar Venta</h2></center>
      <div className="card">
        <div className="card-header">
          <center><h3><p style={{ fontFamily: 'Arial' }}>Ingrese Sus Datos:</p></h3></center>
        </div><br/><br/>
        <center><form className="was-validated">
          <div className="mb-3 mt-3">
            <label htmlFor="ventaId" className="form-label" style={{ fontFamily: 'Arial' }}>ID de Venta: </label>
            <input type="text" className="form-control" id="ventaId" placeholder="Ingrese el ID de la Venta" name="ventaId" required /><br/><br/>
          </div>
          <div className="mb-3">
            <label htmlFor="producto" className="form-label" style={{ fontFamily: 'Arial' }}>Producto: </label>
            <input type="text" className="form-control" id="producto" placeholder="Ingrese el Nombre del Producto" name="producto" required /><br/><br/>
          </div>
          <div className="mb-3">
            <label htmlFor="cantidad" className="form-label" style={{ fontFamily: 'Arial' }}>Cantidad: </label>
            <input type="text" className="form-control" id="cantidad" placeholder="Ingrese la Cantidad Vendida" name="cantidad" required /><br/><br/>
          </div>
          <div className="mb-3">
            <label htmlFor="total" className="form-label" style={{ fontFamily: 'Arial' }}>Total: </label>
            <input type="text" className="form-control" id="total" placeholder="Ingrese el Total de la Venta" name="total" required /><br/><br/>
          </div><br></br>
          <div className="text-center">
            {/* Utiliza Link para redirigir a la página de Ventas al hacer clic en el botón */}
            <button><Link to="/ventas" className="link" style={{ textDecoration: 'none', color: 'white' }}>Editar Venta</Link></button>
          </div>
        </form></center>
      </div>
    </div>
  )
}

export default EditarVenta;
