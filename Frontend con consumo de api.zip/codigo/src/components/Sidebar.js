import React from 'react';
import { Link } from 'react-router-dom';
import profileImage from '../profile.jpg'; 

import './Sidebar.css'; 

function Sidebar() {
  return (
    <div className="sidebar">
      <ul>
      <img src={profileImage} alt="Foto de perfil" style={{ maxWidth: '100%', height: 'auto' }} /><br></br><br></br>
      <center><div className="Name">Dillan Guevara</div></center><br></br>
        <li><Link to="/home" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Home</Link></li><br/>
        <li><Link to="/categorías" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Categorías</Link></li><br/>
        <li><Link to="/productos" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Productos</Link></li><br/>
        <li><Link to="/proveedores" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Proveedores</Link></li><br/>
        <li><Link to="/clientes" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Clientes</Link></li><br/>
        <li><Link to="/ventas" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Ventas</Link></li><br/>
        <li><Link to="/compras" alt="link" className="link" style={{ textDecoration: 'none', color: 'white' }}>Compras</Link></li><br/>
      </ul><br></br><br></br><br></br>
      <button><Link to="/" alt="link" style={{ textDecoration: 'none', color: 'white' }}>Cerrar Sesión</Link></button>
    </div>
  );
}

export default Sidebar;
